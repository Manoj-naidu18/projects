import streamlit as st
import speech_recognition as sr
from google.generativeai import GenerativeModel, configure
import os
import pyttsx3
from dotenv import load_dotenv

# Load environment variables and configure API
load_dotenv()
configure(api_key=os.getenv("GOOGLE_API_KEY"))

# Initialize the generative model
model = GenerativeModel("gemini-pro")

# Initialize speech recognizer
recognizer = sr.Recognizer()

# Initialize text-to-speech engine
engine = pyttsx3.init()

# Function to read text aloud
def read_aloud(text):
    engine.say(text)
    engine.runAndWait()

def get_audio_input():
    try:
        with sr.Microphone() as source:
            st.write("Listening...")
            audio = recognizer.listen(source, timeout=5, phrase_time_limit=5)
        st.write("Processing...")
        text = recognizer.recognize_google(audio)
        return text
    except sr.UnknownValueError:
        st.write("Could not understand audio")
        return ""
    except sr.RequestError as e:
        st.write(f"Could not request results; {e}")
        return ""
    except Exception as e:
        st.write(f"Error: {e}")
        return ""

def get_llm_response(question):
    try:
        response = model.generate_content(question)
        return response.text
    except Exception as e:
        return f"An error occurred: {e}"

# Streamlit UI
st.title("Student Assistance Chatbot")

# Initialize session state
if 'questions' not in st.session_state:
    st.session_state.questions = []
if 'answers' not in st.session_state:
    st.session_state.answers = []

# Text input
text_input = st.text_input("Type your question here:")

# Voice input
if st.button("🎤 Voice Input"):
    text_input = get_audio_input()
    answer = get_llm_response(text_input)
    st.session_state.questions.append(text_input)
    st.session_state.answers.append(answer)
    st.write(f"You said: {text_input}")

# Submit button
if st.button("Submit") and text_input:
    with st.spinner("Getting answer..."):
        answer = get_llm_response(text_input)
    st.session_state.questions.append(text_input)
    st.session_state.answers.append(answer)

# Display conversation history
st.write("### Conversation History:")
for idx, (q, a) in enumerate(zip(st.session_state.questions, st.session_state.answers)):
    with st.expander(f"Q: {q}", expanded=True):
        st.write(f"A: {a}")

        # Add read aloud button for each answer
        if st.button(f"🔊 Read Answer {idx+1}", key=f"read_{idx+1}"):
            read_aloud(a)